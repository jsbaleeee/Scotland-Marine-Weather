/* ==========================================================================
   PortCast — Company login / signup / join / password reset
   Supabase config lives in supabase-config.js (loaded before this file).
   ========================================================================== */
const $ = (id) => document.getElementById(id);
let mode = "login"; // "login" | "signup" | "join"

if (!supabaseClient) {
  $("notConfigured").classList.remove("hidden");
  $("authForm").classList.add("hidden");
}

function setMode(newMode) {
  mode = newMode;
  const tabs = { login: $("tabLogin"), signup: $("tabSignup"), join: $("tabJoin") };
  Object.entries(tabs).forEach(([key, btn]) => {
    const active = key === mode;
    btn.style.background = active ? "var(--brass)" : "transparent";
    btn.style.color = active ? "var(--navy-deep)" : "var(--brass-light)";
  });
  $("companyName").classList.toggle("hidden", mode !== "signup");
  $("inviteCode").classList.toggle("hidden", mode !== "join");
  $("submitBtn").textContent =
    mode === "login" ? "Log in" : mode === "signup" ? "Create company & account" : "Join with invite code";
  $("forgotPasswordBtn").classList.toggle("hidden", mode !== "login");
}

$("tabLogin")?.addEventListener("click", () => setMode("login"));
$("tabSignup")?.addEventListener("click", () => setMode("signup"));
$("tabJoin")?.addEventListener("click", () => setMode("join"));

$("forgotPasswordBtn")?.addEventListener("click", async () => {
  const email = $("email").value.trim();
  const msg = $("authMessage");
  if (!email) { msg.textContent = "Enter your email above first, then tap this again."; return; }

  const { error } = await supabaseClient.auth.resetPasswordForEmail(email, {
    redirectTo: window.location.origin + window.location.pathname.replace("login.html", "reset-password.html"),
  });
  msg.textContent = error ? error.message : "Check your email for a password reset link.";
});

$("submitBtn")?.addEventListener("click", async () => {
  const email = $("email").value.trim();
  const password = $("password").value;
  const msg = $("authMessage");
  msg.textContent = "";

  if (!email || !password) { msg.textContent = "Enter an email and password."; return; }

  if (mode === "login") {
    const { error } = await supabaseClient.auth.signInWithPassword({ email, password });
    if (error) { msg.textContent = error.message; return; }
    window.location.href = "index.html";
    return;
  }

  if (mode === "join") {
    const inviteCode = $("inviteCode").value.trim();
    if (!inviteCode) { msg.textContent = "Enter the invite code your company admin shared with you."; return; }

    const { data: signUpData, error: signUpError } = await supabaseClient.auth.signUp({ email, password });
    if (signUpError) { msg.textContent = signUpError.message; return; }
    if (!signUpData.session) { msg.textContent = "Check your email to confirm your account, then log in and try joining again."; return; }

    // The invite code IS the company's id (see fleet.html — company admins
    // can copy it there to share). RLS only lets you insert your own
    // membership row, but you choose which company_id to join — so this
    // is "secure by an unguessable UUID", similar to a private share link.
    // Fine for a beta; a dedicated short-lived invite-token system would
    // be the more robust version later.
    const { error: memberError } = await supabaseClient
      .from("company_members").insert({ user_id: signUpData.user.id, company_id: inviteCode, role: "staff" });
    if (memberError) { msg.textContent = "Couldn't join — check the invite code is correct: " + memberError.message; return; }

    window.location.href = "index.html";
    return;
  }

  // Signup: create the auth user, then a company, then link them together.
  const companyName = $("companyName").value.trim();
  if (!companyName) { msg.textContent = "Enter a company name."; return; }

  const { data: signUpData, error: signUpError } = await supabaseClient.auth.signUp({ email, password });
  if (signUpError) { msg.textContent = signUpError.message; return; }

  if (!signUpData.session) {
    msg.textContent = "Check your email to confirm your account, then log in.";
    return;
  }

  const { data: company, error: companyError } = await supabaseClient
    .from("companies").insert({ name: companyName }).select().single();
  if (companyError) { msg.textContent = "Account created, but company setup failed: " + companyError.message; return; }

  const { error: memberError } = await supabaseClient
    .from("company_members").insert({ user_id: signUpData.user.id, company_id: company.id, role: "admin" });
  if (memberError) { msg.textContent = "Account created, but linking to company failed: " + memberError.message; return; }

  window.location.href = "index.html";
});

setMode("login");
