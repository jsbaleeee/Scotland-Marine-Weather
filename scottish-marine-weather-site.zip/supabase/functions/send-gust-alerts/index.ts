// PortCast — send-gust-alerts Edge Function
// ============================================================================
// This is the piece that actually SENDS gust alert notifications. The
// browser-side code in app.js only saves a subscription + threshold to the
// push_subscriptions table — nothing gets sent until THIS function runs on
// a schedule and pushes to those subscriptions.
//
// I can write this code, but I can't deploy or schedule it for you — that
// needs your own Supabase login via their CLI. Steps:
//
// 1. Generate a VAPID key pair (one-time):
//      npx web-push generate-vapid-keys
//    Paste the PUBLIC key into VAPID_PUBLIC_KEY in app.js.
//    Keep the PRIVATE key secret — set it as a secret on this function
//    (step 4), never put it in any file that goes to GitHub.
//
// 2. Install the Supabase CLI and log in:
//      npm install -g supabase
//      supabase login
//
// 3. Link this project and deploy the function:
//      supabase link --project-ref <your-project-ref>
//      supabase functions deploy send-gust-alerts
//
// 4. Set secrets the function needs (never commit these anywhere):
//      supabase secrets set VAPID_PRIVATE_KEY=<your private key>
//      supabase secrets set VAPID_PUBLIC_KEY=<same public key as app.js>
//      supabase secrets set VAPID_SUBJECT=mailto:you@example.com
//      supabase secrets set SUPABASE_SERVICE_ROLE_KEY=<from Project Settings > API>
//      (SUPABASE_URL is provided automatically by the platform)
//
// 5. Schedule it to actually run periodically — e.g. every 30 minutes —
//    using Supabase's pg_cron + pg_net (SQL Editor):
//
//      select cron.schedule(
//        'send-gust-alerts-every-30-min',
//        '*/30 * * * *',
//        $$
//        select net.http_post(
//          url := 'https://<your-project-ref>.functions.supabase.co/send-gust-alerts',
//          headers := jsonb_build_object('Authorization', 'Bearer <your service_role key>')
//        );
//        $$
//      );
//
// Until all of the above is done, subscribing in the app saves a row in
// push_subscriptions but nobody actually gets notified — that's the honest
// state of this feature without you completing this deployment yourself.
// ============================================================================

import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import webpush from "https://esm.sh/web-push@3.6.7";

const PORT_COORDS: Record<string, { lat: number; lon: number }> = {
  lerwick: { lat: 60.1547, lon: -1.1494 }, kirkwall: { lat: 58.9807, lon: -2.9605 },
  aberdeen: { lat: 57.1497, lon: -2.0943 }, oban: { lat: 56.4152, lon: -5.4719 },
  mallaig: { lat: 57.0068, lon: -5.8285 }, ullapool: { lat: 57.8956, lon: -5.1608 },
  ardrossan: { lat: 55.6408, lon: -4.8207 }, troon: { lat: 55.5350, lon: -4.6600 },
  gourock: { lat: 55.9581, lon: -4.8148 }, wemyssbay: { lat: 55.8747, lon: -4.8869 },
  largs: { lat: 55.7970, lon: -4.8680 }, claonaig: { lat: 55.7871, lon: -5.4009 },
  tarbertkintyre: { lat: 55.8664, lon: -5.4139 }, kennacraig: { lat: 55.7826, lon: -5.4661 },
  tayinloan: { lat: 55.6417, lon: -5.6614 }, portavadie: { lat: 55.8814, lon: -5.3125 },
  lochaline: { lat: 56.5325, lon: -5.7770 }, kilcreggan: { lat: 55.9758, lon: -4.8309 },
  colintraive: { lat: 55.9336, lon: -5.1519 }, gallanach: { lat: 56.4001, lon: -5.4890 },
  fionnphort: { lat: 56.3244, lon: -6.3789 }, brodick: { lat: 55.5760, lon: -5.1450 },
  lochranza: { lat: 55.7040, lon: -5.3010 }, rothesay: { lat: 55.8386, lon: -5.0533 },
  rhubodach: { lat: 55.9463, lon: -5.1481 }, millport: { lat: 55.7500, lon: -4.9100 },
  gigha: { lat: 55.6820, lon: -5.7370 }, dunoon: { lat: 55.9490, lon: -4.9270 },
  kerrera: { lat: 56.3990, lon: -5.5460 }, iona: { lat: 56.3310, lon: -6.3900 },
  fishnish: { lat: 56.5150, lon: -5.7900 }, tobermory: { lat: 56.6230, lon: -6.0640 },
  kilchoan: { lat: 56.6890, lon: -6.1130 }, craignure: { lat: 56.4720, lon: -5.7020 },
  colonsay: { lat: 56.0790, lon: -6.1770 }, portaskaig: { lat: 55.8460, lon: -6.1050 },
  portellen: { lat: 55.6270, lon: -6.1930 }, castlebay: { lat: 56.9490, lon: -7.4870 },
  eriskay: { lat: 57.0870, lon: -7.2900 }, lochboisdale: { lat: 57.1520, lon: -7.3190 },
  lochmaddy: { lat: 57.5960, lon: -7.1520 }, uig: { lat: 57.5920, lon: -6.3720 },
  armadale: { lat: 57.0640, lon: -5.8990 }, sconser: { lat: 57.3280, lon: -6.1130 },
  raasay: { lat: 57.4060, lon: -6.0540 }, tarbertharris: { lat: 57.8960, lon: -6.7960 },
  stornoway: { lat: 58.2093, lon: -6.3862 }, arinagour: { lat: 56.6160, lon: -6.5310 },
  scarinish: { lat: 56.5010, lon: -6.8010 }, eigg: { lat: 56.8770, lon: -6.1350 },
  muck: { lat: 56.8300, lon: -6.2300 }, rum: { lat: 57.0070, lon: -6.2850 },
  canna: { lat: 57.0550, lon: -6.4700 },
};

Deno.serve(async () => {
  const supabase = createClient(
    Deno.env.get("SUPABASE_URL")!,
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!, // service role bypasses RLS — only used server-side
  );

  webpush.setVapidDetails(
    Deno.env.get("VAPID_SUBJECT")!,
    Deno.env.get("VAPID_PUBLIC_KEY")!,
    Deno.env.get("VAPID_PRIVATE_KEY")!,
  );

  const { data: subs, error } = await supabase.from("push_subscriptions").select("*");
  if (error || !subs) return new Response("Failed to load subscriptions", { status: 500 });

  // Group by port so we only fetch each port's forecast once.
  const byPort: Record<string, typeof subs> = {};
  for (const sub of subs) (byPort[sub.port] ??= []).push(sub);

  let sent = 0;
  for (const [port, portSubs] of Object.entries(byPort)) {
    const coords = PORT_COORDS[port];
    if (!coords) continue;

    const res = await fetch(
      `https://api.open-meteo.com/v1/forecast?latitude=${coords.lat}&longitude=${coords.lon}` +
      `&current=wind_gusts_10m&wind_speed_unit=mph&timezone=auto`
    );
    const data = await res.json();
    const currentGust = data?.current?.wind_gusts_10m;
    if (currentGust == null) continue;

    for (const sub of portSubs) {
      if (currentGust < sub.gust_threshold_mph) continue;
      try {
        await webpush.sendNotification(sub.subscription, JSON.stringify({
          title: `PortCast — gust alert`,
          body: `${Math.round(currentGust)} mph gusts now at this port, above your ${Math.round(sub.gust_threshold_mph)} mph threshold.`,
        }));
        sent++;
      } catch (err) {
        // A 410 here means the subscription has expired/unsubscribed —
        // worth deleting it, but left simple for now.
        console.error(`Push failed for subscription ${sub.id}:`, err);
      }
    }
  }

  return new Response(JSON.stringify({ checked: subs.length, sent }), {
    headers: { "Content-Type": "application/json" },
  });
});
