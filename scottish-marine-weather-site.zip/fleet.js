/* ==========================================================================
   PortCast — Fleet Registry
   Supabase config lives in supabase-config.js (loaded before this file).
   Also opens a lightweight AIS connection to show each vessel's live
   underway/at-berth status — same AISSTREAM_API_KEY as app.js.
   ========================================================================== */
const AISSTREAM_API_KEY = ""; // <-- same value as app.js

const $ = (id) => document.getElementById(id);
let companyId = null;
const vesselStatus = new Map(); // mmsi -> "Underway" | "At berth / anchored"
let aisSocket = null;

async function init() {
  if (!supabaseClient) {
    $("notLoggedIn").classList.remove("hidden");
    $("notLoggedIn").querySelector("p").textContent = "No database is connected yet — set this up first.";
    return;
  }

  const { data: { session } } = await supabaseClient.auth.getSession();
  if (!session) {
    $("notLoggedIn").classList.remove("hidden");
    return;
  }

  const { data: membership, error } = await supabaseClient
    .from("company_members").select("company_id, companies(name)").eq("user_id", session.user.id).single();

  if (error || !membership) {
    $("notLoggedIn").classList.remove("hidden");
    $("notLoggedIn").querySelector("p").textContent = "Couldn't find a company for this account.";
    return;
  }

  companyId = membership.company_id;
  $("companyLabel").textContent = `Managing fleet for ${membership.companies.name}`;
  $("inviteCodeDisplay").textContent = companyId;
  $("fleetContent").classList.remove("hidden");
  await renderVessels();
}

$("copyInviteBtn")?.addEventListener("click", () => {
  navigator.clipboard.writeText(companyId);
  $("copyInviteBtn").textContent = "Copied!";
  setTimeout(() => { $("copyInviteBtn").textContent = "Copy"; }, 1500);
});

async function renderVessels() {
  const { data, error } = await supabaseClient
    .from("vessels").select("*").eq("company_id", companyId).order("name");
  const body = $("vesselTableBody");
  body.innerHTML = "";

  if (error || !data) { return; }
  $("emptyState").classList.toggle("hidden", data.length > 0);

  data.forEach((v) => {
    const tr = document.createElement("tr");
    tr.dataset.mmsi = v.mmsi;
    tr.innerHTML = `
      <td style="color:var(--paper)">${v.name}</td>
      <td style="color:var(--paper-dim)">${v.mmsi}</td>
      <td class="vessel-status-cell" style="color:var(--paper-dim)">${vesselStatus.get(v.mmsi) || "No AIS report yet"}</td>
      <td><button data-id="${v.id}" class="delete-vessel-btn text-[10px] uppercase px-2 py-1 rounded-sm border" style="border-color:var(--admiralty-red); color:#F3C9C4">Remove</button></td>
    `;
    body.appendChild(tr);
  });

  body.querySelectorAll(".delete-vessel-btn").forEach((btn) => {
    btn.addEventListener("click", async () => {
      await supabaseClient.from("vessels").delete().eq("id", Number(btn.dataset.id));
      connectFleetAis(); // MMSI list changed — resubscribe
      await renderVessels();
    });
  });

  connectFleetAis();
}

function connectFleetAis() {
  if (!AISSTREAM_API_KEY) return;
  if (aisSocket) { aisSocket.close(); aisSocket = null; }

  const rows = [...document.querySelectorAll("#vesselTableBody tr")];
  const mmsiList = rows.map((r) => r.dataset.mmsi).filter(Boolean);
  if (!mmsiList.length) return;

  aisSocket = new WebSocket("wss://stream.aisstream.io/v0/stream");
  aisSocket.onopen = () => {
    aisSocket.send(JSON.stringify({
      APIKey: AISSTREAM_API_KEY,
      BoundingBoxes: [[[-90, -180], [90, 180]]],
      FiltersShipMMSI: mmsiList,
      FilterMessageTypes: ["PositionReport"],
    }));
  };
  aisSocket.onmessage = (event) => {
    try {
      const msg = JSON.parse(event.data);
      const pr = msg?.Message?.PositionReport;
      const mmsi = msg?.MetaData?.MMSI;
      if (!pr || !mmsi) return;
      const status = pr.Sog < 0.5 ? "At berth / anchored" : "Underway";
      vesselStatus.set(String(mmsi), status);
      const row = document.querySelector(`#vesselTableBody tr[data-mmsi="${mmsi}"]`);
      if (row) row.querySelector(".vessel-status-cell").textContent = status;
    } catch { /* ignore malformed frame */ }
  };
}

$("addVesselForm")?.addEventListener("submit", async (e) => {
  e.preventDefault();
  const name = $("vesselName").value.trim();
  const mmsi = $("vesselMmsi").value.trim();
  if (!name || !mmsi) return;

  const { error } = await supabaseClient.from("vessels").insert({ company_id: companyId, name, mmsi });
  if (error) { alert("Couldn't add vessel: " + error.message); return; }

  $("vesselName").value = "";
  $("vesselMmsi").value = "";
  await renderVessels();
});

init();
